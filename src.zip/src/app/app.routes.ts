import { Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PickersComponent } from './pickers/pickers.component';
import { PutawayComponent } from './putaway/putaway.component';
import { SequencePlanComponent } from './sequence-plan/sequence-plan.component';
import {InventoryComponent} from './inventory/inventory.component';
import { LoginComponent } from './login/login.component';

export const routes: Routes = [

  {path:'dashboard',component:DashboardComponent},
  {path:'inventory',component:InventoryComponent},
  {path:'pickers',component:PickersComponent},
  {path:'putaway',component:PutawayComponent},
  {path:'sequenceplan',component:SequencePlanComponent},


  {path:'',component:LoginComponent},

];
