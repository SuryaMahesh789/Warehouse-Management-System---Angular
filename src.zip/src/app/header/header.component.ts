import {Component, EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'app-header',
  standalone: true,
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  isHosur() {
    return window.location.pathname === '/sequenceplan';
  }

  @Output() colorChanged = new EventEmitter<string>();

  changeColor(event: any) {
    const selectedValue = event.target.value;
    this.colorChanged.emit("#FF8457");
  }
}
