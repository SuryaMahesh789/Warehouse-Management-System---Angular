import { Component } from '@angular/core';
import {HeaderComponent} from "../header/header.component";
import {NavbarComponent} from "../navbar/navbar.component";

@Component({
  selector: 'app-pickers',
  standalone: true,
    imports: [
        HeaderComponent,
        NavbarComponent
    ],
  templateUrl: './pickers.component.html',
  styleUrl: './pickers.component.css'
})
export class PickersComponent {

}
