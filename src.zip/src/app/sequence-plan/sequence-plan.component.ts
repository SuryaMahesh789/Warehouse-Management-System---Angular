import { Component } from '@angular/core';
import {HeaderComponent} from "../header/header.component";
import {NavbarComponent} from "../navbar/navbar.component";

@Component({
  selector: 'app-sequence-plan',
  standalone: true,
    imports: [
        HeaderComponent,
        NavbarComponent
    ],
  templateUrl: './sequence-plan.component.html',
  styleUrl: './sequence-plan.component.css'
})
export class SequencePlanComponent {

}
