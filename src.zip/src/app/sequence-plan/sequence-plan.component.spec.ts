import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SequencePlanComponent } from './sequence-plan.component';

describe('SequencePlanComponent', () => {
  let component: SequencePlanComponent;
  let fixture: ComponentFixture<SequencePlanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SequencePlanComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SequencePlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
