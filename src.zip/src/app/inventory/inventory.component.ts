import {Component, Input} from '@angular/core';
import {HeaderComponent} from "../header/header.component";
import {NavbarComponent} from "../navbar/navbar.component";
import {NgIf, NgStyle} from "@angular/common";

@Component({
  selector: 'app-inventory',
  standalone: true,
  imports: [
    HeaderComponent,
    NavbarComponent,
    NgStyle,
    NgIf
  ],
  templateUrl: './inventory.component.html',
  styleUrl: './inventory.component.css'
})
export class InventoryComponent {
  selectedColor: string = '';
  selectedColor1: string = '';

  onColorChanged(color: string) {
    this.selectedColor = color;
    this.selectedColor1 = "#7CFC00";
  }
  containerVisible: boolean = false;

  toggleContainerVisibility() {
    this.containerVisible = !this.containerVisible;
    console.log("hi")
  }

  zoomLevel: number = 1;

  zoomIn(): void {
    this.zoomLevel += 0.1;
  }

  zoomOut(): void {
    if (this.zoomLevel > 0.1) {
      this.zoomLevel -= 0.1;
    }
  }
}
