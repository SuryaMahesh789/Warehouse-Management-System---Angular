import { Component, AfterViewInit } from '@angular/core';
import * as echarts from 'echarts';
import { HeaderComponent } from "../header/header.component";
import { NavbarComponent } from "../navbar/navbar.component";
import {FormsModule} from "@angular/forms";
import {NgForOf, NgIf} from "@angular/common";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  standalone: true,
  imports: [
    HeaderComponent,
    NavbarComponent,
    FormsModule,
    NgIf,
    NgForOf
  ],
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements AfterViewInit {
  gaugeValue: number = 0;

  constructor() {
  }

  zoomLevel: number = 1;

  zoomIn(): void {
    this.zoomLevel += 0.1;
  }

  zoomOut(): void {
    if (this.zoomLevel > 0.1) {
      this.zoomLevel -= 0.1;
    }
  }

  ngAfterViewInit(): void {
    this.renderGaugeChart(); // Call the function to render the gauge chart after view initialization
  }

// Function to render the gauge chart
  renderGaugeChart(): void {
    const data = this.generateRandomData();
    const chartDom = document.getElementById('gauge-chart') as HTMLDivElement;
    if (chartDom) {
      const myChart = echarts.init(chartDom);

      // Option for the gauge chart
      const option: echarts.EChartsOption = {
        series: [{
          type: 'gauge',
          center: ['50%', '60%'],
        }]
      };

      // Set interval to update chart data
      setInterval(() => {
        this.gaugeValue = Math.floor(Math.random() * 60);
        myChart.setOption({
          series: [{
            data: [{value: this.gaugeValue}]
          }]
        });
      }, 2000);

      myChart.setOption(option);
    } else {
      console.error('DOM element not found for gauge chart.');
    }
  }

// Generate random data for 50 rows
  generateRandomData(): any[] {
    const rowData = [];
    for (let i = 1; i <= 50; i++) {
      rowData.push({
        slno: i,
        invoiceNumber: `INV-${i}`,
        poNumber: `PO-${i}`,
        partNumber: `PART-${i}`,
        partDescription: `Description ${i}`,
        binQuantity: Math.floor(Math.random() * 100) + 1,
        receiptQuantity: Math.floor(Math.random() * 50) + 1,
        supplierCodeName: `Supplier ${String.fromCharCode(65 + (i % 5))}`,
        vehicleNumber: `Vehicle ${i}`,
        receivedBy: `Person ${i}`,
        action: 'Action',
      });
    }
    return rowData;
  }


  tableData: any[] = [
    {
      SlNo: 1,
      InvoiceNumber: 'INV-2024-0001',
      BarcodeNumber: '2345678901234567',
      PONumber: 'PO-TVS-1234',
      PartNumber: 'TVS-ENG-0001',
      PartDescription: 'Engine Block, Motorcycle',
      BinQuantity: 10,
      ReceiptQuantity: 20,
      SupplierCodeName: 'SUP-ABC - Acme Bolts & Co.',
      VehicleNumber: 'MH-01-TVS2345',
      ReceivedBy: 'John Doe',
      Action: 'Receive'
    },
    {
      SlNo: 2,
      InvoiceNumber: 'INV-2024-0002',
      BarcodeNumber: '2345678901234567',
      PONumber: 'PO-TVS-2345',
      PartNumber: 'TVS-ELEC-0012',
      PartDescription: 'Headlight Assembly, Motorcycle',
      BinQuantity: 5,
      ReceiptQuantity: 10,
      SupplierCodeName: 'SUP-XYZ - XYZ Electronics',
      VehicleNumber: 'KA-05-TVS1234',
      ReceivedBy: 'Jane Smith',
      Action: 'Receive'
    },
    {
      SlNo: 3,
      InvoiceNumber: 'INV-2024-0003',
      BarcodeNumber: '2345678901234567',
      PONumber: 'PO-TVS-3456',
      PartNumber: 'TVS-PLA-0023',
      PartDescription: 'Plastic Fairing Panel, Motorcycle',
      BinQuantity: 20,
      ReceiptQuantity: 20,
      SupplierCodeName: 'SUP-MNO - MNO Plastic Compone',
      VehicleNumber: 'TN-10-TVS5678',
      ReceivedBy: 'David Lee',
      Action: 'Receive'
    },
    {
      SlNo: 4,
      InvoiceNumber: 'INV-2024-0004',
      BarcodeNumber: '2345678901234567',
      PONumber: 'PO-TVS-4567',
      PartNumber: 'TVS-WHE-0034',
      PartDescription: 'Wheel Rim, Motorcycle (17 inch)',
      BinQuantity: 15,
      ReceiptQuantity: 15,
      SupplierCodeName: 'SUP-DEF - DEF Wheel Manufactur',
      VehicleNumber: 'KL-15-TVS9012',
      ReceivedBy: 'Michael Chen',
      Action: 'Receive'
    },
    {
      SlNo: 5,
      InvoiceNumber: 'INV-2024-0005',
      BarcodeNumber: '2345678901234567',
      PONumber: 'PO-TVS-5678',
      PartNumber: 'TVS-BAT-0045',
      PartDescription: 'Battery, Motorcycle (12V)',
      BinQuantity: 8,
      ReceiptQuantity: 10,
      SupplierCodeName: 'SUP-GHI - GHI Battery Solutions',
      VehicleNumber: 'AP-20-TVS3456',
      ReceivedBy: 'Emily Jones',
      Action: 'Receive'
    },
    {
      SlNo: 6,
      InvoiceNumber: 'INV-2024-0006',
      BarcodeNumber: '7890123456789012',
      PONumber: 'PO-TVS-6789',
      PartNumber: 'TVS-OIL-0056',
      PartDescription: 'Engine Oil, Motorcycle (Synthetic, 10W40',
      BinQuantity: 25,
      ReceiptQuantity: 25,
      SupplierCodeName: 'SUP-JKL - JKL Lubricants',
      VehicleNumber: 'HR-25-TVS7890',
      ReceivedBy: 'Daniel Garcia',
      Action: 'Receive'
    },
    {
      SlNo: 7,
      InvoiceNumber: 'INV-2024-0007',
      BarcodeNumber: '4567890123456789',
      PONumber: 'PO-TVS-7890',
      PartNumber: 'TVS-CHA-0067',
      PartDescription: 'Motorcycle Chain & Sprocket Kit (520 Cha',
      BinQuantity: 5,
      ReceiptQuantity: 8,
      SupplierCodeName: 'SUP-PQR - PQR Drive Components',
      VehicleNumber: 'MH-01-TVS2345',
      ReceivedBy: 'John Doe',
      Action: 'Issue'
    },
    {
      SlNo: 8,
      InvoiceNumber: 'INV-2024-0008',
      BarcodeNumber: '1234567890123456',
      PONumber: 'PO-TVS-8901',
      PartNumber: 'TVS-FIL-0078',
      PartDescription: 'Motorcycle Air Filter (High Performance)',
      BinQuantity: 3,
      ReceiptQuantity: 5,
      SupplierCodeName: 'SUP-STU - STU Air Filtration Syste',
      VehicleNumber: 'KA-05-TVS1234',
      ReceivedBy: 'Jane Smith',
      Action: 'Issue'
    }
  ];

  searchTerm: string = '';
  filteredData: any[] = [];
  showTable: boolean = true;

  ngOnInit(): void {
    this.filteredData = this.tableData;
  }

  filterData(): void {
    if (this.searchTerm) {
      this.filteredData = this.tableData.filter(item =>
        item.InvoiceNumber.toLowerCase().includes(this.searchTerm.toLowerCase())
      );
      this.showTable = false;
    } else {
      this.filteredData = this.tableData;
      this.showTable = true;
    }
  }
}
